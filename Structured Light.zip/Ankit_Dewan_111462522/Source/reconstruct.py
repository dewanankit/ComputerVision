# ================================================
# Skeleton codes for HW5
# Read the skeleton codes carefully and put all your
# codes into function "reconstruct_from_binary_patterns"
# ================================================

import cv2
import numpy as np
from math import log, ceil, floor
import matplotlib.pyplot as plt
import pickle
import sys
from cv2 import imshow
from numpy import float32, dtype
from networkx.algorithms.bipartite.basic import color

def help_message():
    # Note: it is assumed that "binary_codes_ids_codebook.pckl", "stereo_calibration.pckl",
    # and images folder are in the same root folder as your "generate_data.py" source file.
    # Same folder structure will be used when we test your program

    print("Usage: [Output_Directory]")
    print("[Output_Directory]")
    print("Where to put your output.xyz")
    print("Example usages:")
    print(sys.argv[0] + " ./")

def reconstruct_from_binary_patterns():
    scale_factor = 1.0
    ref_white = cv2.resize(cv2.imread("images/pattern000.jpg", cv2.IMREAD_GRAYSCALE) / 255.0, (0,0), fx=scale_factor,fy=scale_factor)
    ref_black = cv2.resize(cv2.imread("images/pattern001.jpg", cv2.IMREAD_GRAYSCALE) / 255.0, (0,0), fx=scale_factor,fy=scale_factor)
    ref_avg   = (ref_white + ref_black) / 2.0
    ref_on    = ref_avg + 0.05 # a threshold for ON pixels
    ref_off   = ref_avg - 0.05 # add a small buffer region
    '''cv2.imshow('pqr',ref_white)
    cv2.waitKey(0)
    cv2.destroyAllWindows()'''
    h,w = ref_white.shape
    image = cv2.imread("images/pattern001.jpg")
    
    # mask of pixels where there is projection
    proj_mask = (ref_white > (ref_black + 0.05))
    
    scan_bits = np.zeros((h,w), dtype=np.uint16)
    correspondence_matrix = np.zeros((h,w,3), dtype=np.float32)

    # analyze the binary patterns from the camera
    for i in range(0,15):
        # read the file
        patt_gray = cv2.resize(cv2.imread("images/pattern%03d.jpg"%(i+2), cv2.IMREAD_GRAYSCALE) / 255.0, (0,0), fx=scale_factor,fy=scale_factor)
        # mask where the pixels are ON
        on_mask = (patt_gray > ref_on) & proj_mask

        # this code corresponds with the binary pattern code
        bit_code = np.uint16(1 << i)
        
        # TODO: populate scan_bits by putting the bit_code according to on_mask
        for k in range(h):
            for j in range(w):
                if(on_mask[k,j] == True):
                    scan_bits[k,j] = scan_bits[k,j] + bit_code
                    #print True
        #print i        
        #print on_mask
    #print scan_bits
    print("load codebook")
    # the codebook translates from <binary code> to (x,y) in projector screen space
    with open("binary_codes_ids_codebook.pckl","r") as f:
        binary_codes_ids_codebook = pickle.load(f)

    camera_points = []
    projector_points = []
    color_matrix = []
    for x in range(w):
        for y in range(h):
            if not proj_mask[y,x]:
                continue # no projection here
            if scan_bits[y,x] not in binary_codes_ids_codebook:
                continue # bad binary code
            # TODO: use binary_codes_ids_codebook[...] and scan_bits[y,x] to
            # TODO: find for the camera (x,y) the projector (p_x, p_y).
            # TODO: store your points in camera_points and projector_points
            x_p, y_p = binary_codes_ids_codebook[scan_bits[y,x]]
            if x_p >= 1279 or y_p >= 799:
                #print x_p,y_p
                continue
            camera_points.append((x/2.0,y/2.0))
            projector_points.append((x_p,y_p))
            correspondence_matrix[y,x] = [0,y_p,x_p]
            color_matrix.append((image[y,x,2],image[y,x,1],image[y,x,0]))
             
    color_matrix = np.array(np.reshape(color_matrix, (len(color_matrix),1,3)),dtype = np.float32)
    
    y_max = 0
    x_max= 0
    for x in range(w):
        for y in range(h):
            if(correspondence_matrix[y][x][1] > y_max):
                y_max = correspondence_matrix[y][x][1]
            if(correspondence_matrix[y][x][2] > x_max):
                x_max = correspondence_matrix[y][x][2]
    for x in range(w):
        for y in range(h):
            p = correspondence_matrix[y][x][0]
            q = correspondence_matrix[y][x][1]
            r = correspondence_matrix[y][x][2]
            q = (q*255.0)/float(799)
            r = (r*255.0)/float(1279)
            correspondence_matrix[y,x] = [p,q,r]
    
    cv2.imwrite('correspondence.jpg',correspondence_matrix)
    '''cv2.waitKey(0)
    cv2.destroyAllWindows()'''
            # IMPORTANT!!! : due to differences in calibration and acquisition - divide the camera points by 2
    
    # now that we have 2D-2D correspondances, we can triangulate 3D points!
    
    # load the prepared stereo calibration between projector and camera
    point3d = []
    with open("stereo_calibration.pckl","r") as f:
        d = pickle.load(f)
        camera_K    = d['camera_K']
        camera_d    = d['camera_d']
        projector_K = d['projector_K']
        projector_d = d['projector_d']
        projector_R = d['projector_R']
        projector_t = d['projector_t']
        projection_matrix = np.hstack((projector_R,projector_t))
        camera_matrix = np.identity(3, dtype= float32)
        #print camera_matrix
        mat =  np.zeros((3,1),dtype = float32)
        camera_matrix = np.hstack((camera_matrix,mat))
        #print camera_matrix
        camera_points = np.array(np.reshape(camera_points, (len(camera_points),1,2)),dtype = np.float32)
        projector_points = np.array(np.reshape(projector_points, (len(camera_points),1,2)),dtype = np.float32)
        # TODO: use cv2.undistortPoints to get normalized points for projector, use projector_K and projector_d
        camera_undistort_pts = cv2.undistortPoints(camera_points,camera_K, camera_d)
        projector_undistort_pts = cv2.undistortPoints(projector_points,projector_K, projector_d)
        # TODO: use cv2.triangulatePoints to triangulate the normalized points
        triangulated_pts = cv2.triangulatePoints(camera_matrix, projection_matrix,camera_undistort_pts, projector_undistort_pts)
        
        # TODO: use cv2.convertPointsFromHomogeneous to get real 3D points
        homogeneous_points = cv2.convertPointsFromHomogeneous(np.transpose(triangulated_pts))
        # TODO: name the resulted 3D points as "points_3d"
        color_array = []
        mask = (homogeneous_points[:,:,2] > 200) & (homogeneous_points[:,:,2] < 1400)
        for i in range(len(mask)):
            if(mask[i] == True):
                point3d.append(homogeneous_points[i])
                color_array.append(np.concatenate((homogeneous_points[i],color_matrix[i]),axis=1))
        #print color_array
        point3d = np.array(point3d)
        color_array = np.array(color_array)
        '''with open("output_color.xyz","w") as f:
            for p in color_array:
                f.write("%d %d %d %d %d %d\n"%(p[0,0],p[0,1],p[0,2],p[0,3],p[0,4],p[0,5]))'''
        #return points_3d
        
        
        # TODO: use cv2.undistortPoints to get normalized points for camera, use camera_K and camera_d
    return point3d,color_array
def write_3d_points(points_3d):
    
    # ===== DO NOT CHANGE THIS FUNCTION =====
    
    print("write output point cloud")
    print(points_3d.shape)
    output_name = sys.argv[1] + "output.xyz"
    with open(output_name,"w") as f:
        for p in points_3d:
            f.write("%d %d %d\n"%(p[0,0],p[0,1],p[0,2]))
if __name__ == '__main__':

	# ===== DO NOT CHANGE THIS FUNCTION =====
	
	# validate the input arguments
    if (len(sys.argv) != 2):
        help_message()
        sys.exit()

    points_3d,color_array = reconstruct_from_binary_patterns()
    write_3d_points(points_3d)
    with open("output_color.xyz","w") as f:
        for p in color_array:
            f.write("%d %d %d %d %d %d\n"%(p[0,0],p[0,1],p[0,2],p[0,3],p[0,4],p[0,5]))
	
